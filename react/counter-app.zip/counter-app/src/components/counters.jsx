import React, { Component } from 'react';
import Counter from './counter';


class Counterss extends Component {
    
    render() { 
        const { onReset, counters, onDelete, onIncrement} = this.props
        return (
            <div>
                <button onClick={onReset} className="btn btn-primary btn-small m-2">Reset</button>
                {/* value={counter.value} id={counter.id} */}
                {counters.map(counter =>
                    <Counter key={counter.id} counter={counter} onDelete={onDelete} onIncrement={onIncrement}>
                    </Counter>
                )}
            </div>
        );
    }
}
 
export default Counterss;